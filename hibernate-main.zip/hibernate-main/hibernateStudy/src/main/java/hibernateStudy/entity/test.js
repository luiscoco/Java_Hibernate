let str = 'b'+'a'++'a'+'a';
console.log(str);